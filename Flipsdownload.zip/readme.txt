Thank you for purchasing Flips!

If you ever delete this song, you can download it from this link
http://game103.net/jgmusic/flips.mp3

Also, by downloading the song, you agree that you won't upload
it anywhere on the internet, or share the link given above, Thanks!

Copyright Game 103 2009 All Rights Reserved
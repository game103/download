﻿function onDetailsView(item) {
  var html_for_details_view = "<html><head></head><body>"
  html_for_details_view += "<embed src=http://game103.net/CocoaCatch.swf width=550 height=400>";
  html_for_details_view += "</body></html>";
  
  var control = new DetailsView();
  var tm = new Date();
  control.SetContent("Cocoa Catch", tm.getVarDate(), html_for_details_view,
    true, item.layout);
  control.html_content = true;

  var details = new Object();
  details.details_control = control;
  
  return details;
}




contentArea.contentFlags = gddContentFlagHaveDetails;

var item = new ContentItem();
item.heading = "Cocoa Catch";    
item.onDetailsView = onDetailsView;
contentArea.addContentItem(item, gddItemDisplayInSidebar); 
item.flags = gddContentItemFlagNoRemove;